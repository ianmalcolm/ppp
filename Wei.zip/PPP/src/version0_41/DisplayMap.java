package version0_41;
/*
 * 	Author: Hao Wei
 * 	Time:	14/05/2013
 */
public class DisplayMap {
	public static void main(String[] args){
		PPP ppp = new PPP(10, 5, 3);
		ppp.displayPPP();
	}
}
