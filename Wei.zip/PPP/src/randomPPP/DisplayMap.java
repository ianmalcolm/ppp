package randomPPP;
/*
 * 	Author: Hao Wei
 * 	Time:	11/05/2013
 */
public class DisplayMap {
	public static void main(String[] args){
		PPP p = new PPP(20);
		p.displayPPP();
		p.writePPP(50);
	}
}
