package version0_3;
/*
 * 	Author: Hao Wei
 * 	Time:	13/05/2013
 */
public class DisplayMap {
	public static void main(String[] args){
		Map map = new Map(20, 10, 7);
		map.displayMap();
	}
}
