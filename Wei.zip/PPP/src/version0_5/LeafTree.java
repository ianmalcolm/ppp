package version0_5;
/*
 * 	Author:	Hao Wei
 * 	Time:	27/05/2013
 * 	Purpose: The LeafTree is used for representing a tree only with leafs.
 */
public class LeafTree {
	LeafTree sibling;		// represent its sibling in the tree
	int type;				// 0 represents for leaf, 1 represents for junction
	public LeafTree(){
		
	}
}
