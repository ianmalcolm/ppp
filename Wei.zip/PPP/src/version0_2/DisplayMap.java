package version0_2;
/*
 * 	Author: Hao Wei
 * 	Time:	11/05/2013
 */
public class DisplayMap {
	public static void main(String[] args){
		Map map = new Map(20, 5, 5);
		map.displayMap();
	}
}
